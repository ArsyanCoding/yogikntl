<?php
// user setting
define('CONSUMER_KEY', 'qARBpIn1PLZLOV2xg9aZpEqsH'); //isi
define('CONSUMER_SECRET', 'j90TbjMCd0eGUufMQF4YmqF9DnKUdWFBTTAOCLR1ztRfBW3hwj'); //isi
define('access_token', '1218425607052115968-UCiKtH7a8YNjVSPCCm6gBBy7bWSDem'); //isi
define('access_token_secret', 'amhFFzgoZ4545hay2IgMPc5CU8MI9S1U6AHLOVV5w3rOn'); //isi